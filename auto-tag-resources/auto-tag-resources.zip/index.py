import json
import boto3
import os

ec2_client = boto3.client('ec2')
s3_client = boto3.client('s3')
rds_client = boto3.client('rds')
sns_client = boto3.client('sns')

# Define the tag keys and values
TAGS = [
    {'Key': 'Owner', 'Value': ''},  # 'Owner' value will be set dynamically
    {'Key': 'region', 'Value': os.environ['AWS_REGION']},
    {'Key': 'environment', 'Value': 'production'}
]

# Get the SNS topic ARN from environment variables
SNS_TOPIC_ARN = os.environ['SNS_TOPIC_ARN']

def check_for_tag(tag_list, tag_key):
    print(f'Looking for tag [{tag_key}] in list {json.dumps(tag_list)}')
    for tag in tag_list:
        if tag['Key'] == tag_key:
            return True
    return False

def tag_resource(resource_arn, tags, resource_type):
    try:
        if resource_type == 's3':
            s3_client.put_bucket_tagging(
                Bucket=resource_arn,
                Tagging={'TagSet': tags}
            )
        elif resource_type == 'ec2':
            ec2_client.create_tags(
                Resources=[resource_arn],
                Tags=tags
            )
        elif resource_type == 'rds':
            rds_client.add_tags_to_resource(
                ResourceName=resource_arn,
                Tags=tags
            )
    except Exception as e:
        print(f'Error tagging {resource_type} resource {resource_arn}: {str(e)}')
        send_sns_notification(
            f'Error tagging {resource_type} resource {resource_arn}: {str(e)}',
            f'{resource_type.capitalize()} Tagging Error'
        )
        raise

def send_sns_notification(message, subject):
    try:
        sns_client.publish(
            TopicArn=SNS_TOPIC_ARN,
            Message=message,
            Subject=subject
        )
    except Exception as e:
        print(f'Error sending SNS notification: {str(e)}')

def lambda_handler(event, context):
    print(json.dumps(event))

    try:
        # IAM user
        user = event['detail']['userIdentity']['userName']
    except KeyError:
        user = event['detail']['userIdentity']['arn'].rsplit('/', 1)[-1]
    
    TAGS[0]['Value'] = user  # Set the 'Owner' tag value

    try:
        if event['source'] == "aws.s3":
            bucket_name = event['detail']['requestParameters']['bucketName']

            # Check for existing tags
            try:
                bucket_tags = s3_client.get_bucket_tagging(Bucket=bucket_name)['TagSet']
                if check_for_tag(bucket_tags, 'Owner'):
                    print(f'Bucket [{bucket_name}] is already tagged with [Owner]')
                else:
                    print(f'Tagging Bucket [{bucket_name}] with tags {json.dumps(TAGS)}')
                    tag_resource(bucket_name, TAGS, 's3')
            except s3_client.exceptions.NoSuchTagSet:
                print(f'No tags found on bucket [{bucket_name}]')
                print(f'Tagging Bucket [{bucket_name}] with tags {json.dumps(TAGS)}')
                tag_resource(bucket_name, TAGS, 's3')
            
            send_sns_notification(
                f'S3 bucket [{bucket_name}] was created without tags and has been tagged.',
                'S3 Bucket Tagging Notification'
            )

        elif event['source'] == "aws.ec2":
            instances = event['detail']['responseElements']['instancesSet']['items']
            instance_ids = [i['instanceId'] for i in instances]

            response = ec2_client.describe_instances(InstanceIds=instance_ids)
            for reservation in response['Reservations']:
                for instance in reservation['Instances']:
                    instance_id = instance['InstanceId']
                    if 'Tags' in instance and check_for_tag(instance['Tags'], 'Owner'):
                        print(f'Instance [{instance_id}] is already tagged with [Owner]')
                    else:
                        print(f'Tagging Instance [{instance_id}] with tags {json.dumps(TAGS)}')
                        tag_resource(instance_id, TAGS, 'ec2')
            
            send_sns_notification(
                f'EC2 instances {instance_ids} were created without tags and have been tagged.',
                'EC2 Instance Tagging Notification'
            )

        elif event['source'] == "aws.rds":
            db_instance_arn = event['detail']['responseElements']['dBInstanceArn']
            rds_tags = rds_client.list_tags_for_resource(ResourceName=db_instance_arn)['TagList']

            if check_for_tag(rds_tags, 'Owner'):
                print(f'RDS Instance [{db_instance_arn}] is already tagged with [Owner]')
            else:
                print(f'Tagging RDS Instance [{db_instance_arn}] with tags {json.dumps(TAGS)}')
                tag_resource(db_instance_arn, TAGS, 'rds')
            
            send_sns_notification(
                f'RDS instance [{db_instance_arn}] was created without tags and has been tagged.',
                'RDS Instance Tagging Notification'
            )
    except Exception as e:
        print(f'Error processing event: {str(e)}')
        send_sns_notification(
            f'Error processing event: {str(e)}',
            'Resource Tagging Error'
        )
        raise

    return
